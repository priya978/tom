# Calculate wordcount using hadoop and mapreduce

- Mapper to tokenize words
- Reducer to aggragate word count
- Apache maven to find dependent librararies
